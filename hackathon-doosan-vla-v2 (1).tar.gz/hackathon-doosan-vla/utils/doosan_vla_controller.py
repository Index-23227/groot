"""
배포: VLA Inference Server ↔ Action Adapter ↔ Robot 제어 루프
- Temporal Blending: chunk 경계에서 action을 가중 평균하여 smooth motion
- Chunk Execution: execute_horizon만큼 실행 후 re-plan (시각 피드백 반영)
- Retry Logic: 그리퍼 상태 기반 grasp 실패 감지 + 재시도

사용법:
  # Temporal Blending 모드 (권장)
  python utils/doosan_vla_controller.py --mode blend --vla-url http://localhost:5555 \
    --instruction "Pick up the blue bottle and place it on the tray"

  # 기존 단순 루프 (비교용)
  python utils/doosan_vla_controller.py --mode simple --vla-url http://localhost:5555
"""

import os, sys, time, argparse
import numpy as np
import requests

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from configs.doosan_e0509_config import *
from utils.doosan_action_adapter import DoosanActionAdapter, DoosanSafetyConfig


class VLAClient:
    def __init__(self, url):
        self.url = url

    def predict(self, image, state, instruction):
        """VLA 서버에 예측 요청 → action chunk (N, 7) 반환"""
        import base64
        from io import BytesIO
        from PIL import Image
        buf = BytesIO()
        Image.fromarray(image).save(buf, format="JPEG", quality=85)
        try:
            r = requests.post(f"{self.url}/predict",
                json={"image": base64.b64encode(buf.getvalue()).decode(),
                      "state": state.tolist(), "instruction": instruction}, timeout=3)
            r.raise_for_status()
            actions = np.array(r.json()["actions"])
            if actions.ndim == 1:
                actions = actions.reshape(1, -1)
            return actions
        except Exception as e:
            print(f"[VLA] {e}")
            return None


class TemporalBlender:
    """
    Temporal Blending으로 chunk 경계의 jerk를 제거.

    원리:
    - VLA는 한 번에 chunk_size개의 action을 예측 (예: 16개)
    - 그 중 execute_horizon개만 실행하고, 다시 현재 이미지로 re-plan
    - 새 chunk의 앞부분과 이전 chunk의 뒷부분이 겹치는 구간에서 가중 평균
    - 이렇게 하면 chunk 전환 시 급격한 action 변화가 사라짐

    예시 (chunk_size=16, execute_horizon=4, overlap=4):
      chunk N:  [a0, a1, a2, a3, a4, a5, a6, ...]  ← a0~a3 실행
      chunk N+1:           [b0, b1, b2, b3, b4, ...]  ← 새로 예측
      overlap 구간:         a4↔b0, a5↔b1, a6↔b2, a7↔b3  ← blending
      실행:                 blend(a4,b0), blend(a5,b1), ...
    """

    def __init__(self, execute_horizon=4, overlap=4, decay=0.7):
        """
        Args:
            execute_horizon: 한 chunk에서 실제 실행할 action 수
            overlap: 이전 chunk 잔여분과 새 chunk를 blending할 구간
            decay: blending weight (0→이전 chunk 유지, 1→새 chunk 즉시 전환)
                   0.7이면 새 chunk 쪽에 더 높은 가중치
        """
        self.execute_horizon = execute_horizon
        self.overlap = overlap
        self.decay = decay
        self.prev_chunk_remainder = None

    def blend(self, new_chunk):
        """
        새 action chunk와 이전 잔여분을 blending하여 실행할 actions 반환.

        Args:
            new_chunk: (chunk_size, action_dim) VLA가 예측한 새 action chunk

        Returns:
            execute_actions: (execute_horizon, action_dim) 이번에 실행할 actions
        """
        new_chunk = new_chunk.copy()  # 원본 변경 방지
        chunk_size = len(new_chunk)

        if self.prev_chunk_remainder is not None and len(self.prev_chunk_remainder) > 0:
            blend_len = min(len(self.prev_chunk_remainder), self.overlap, chunk_size)
            for i in range(blend_len):
                w = self.decay * (i + 1) / blend_len
                new_chunk[i] = (1 - w) * self.prev_chunk_remainder[i] + w * new_chunk[i]

        exec_end = min(self.execute_horizon, chunk_size)
        execute_actions = new_chunk[:exec_end]

        if exec_end < chunk_size:
            self.prev_chunk_remainder = new_chunk[exec_end:].copy()
        else:
            self.prev_chunk_remainder = None

        return execute_actions

    def reset(self):
        self.prev_chunk_remainder = None


class DoosanRobot:
    def __init__(self):
        self.connected = False
        self.latest_joints = np.zeros(NUM_JOINTS)
        self.gripper_width = 0.0
        try:
            import rclpy
            from sensor_msgs.msg import JointState
            try: rclpy.init()
            except RuntimeError: pass
            self.node = rclpy.create_node("vla_controller")
            self.node.create_subscription(JointState,
                f"/dsr01{ROBOT_MODEL}/joint_states", self._cb, 10)
            self.connected = True
        except ImportError:
            print("[Robot] MOCK mode")

    def _cb(self, msg):
        self.latest_joints = np.array(msg.position[:NUM_JOINTS])

    def get_state(self):
        if self.connected:
            import rclpy
            rclpy.spin_once(self.node, timeout_sec=0.01)
        return self.latest_joints.copy(), self.gripper_width

    def send(self, joints, gripper_open, dt=0.1):
        deg = np.rad2deg(joints).tolist()
        g = "OPEN" if gripper_open else "CLOSE"
        print(f"[CMD] [{', '.join(f'{d:.1f}' for d in deg)}] {g}")

    def is_object_grasped(self, threshold=0.005):
        return self.gripper_width > threshold


def run_with_blending(args):
    """Temporal Blending 적용된 메인 제어 루프"""
    from utils.doosan_recorder import CameraCapture

    vla = VLAClient(args.vla_url)
    robot = DoosanRobot()
    adapter = DoosanActionAdapter()
    camera = CameraCapture()
    blender = TemporalBlender(
        execute_horizon=args.execute_horizon,
        overlap=args.overlap,
        decay=args.blend_decay,
    )
    dt = 1.0 / args.hz
    total_steps = 0

    print(f"\n=== Deploy (Temporal Blending) ===")
    print(f"  Instruction: {args.instruction}")
    print(f"  Hz: {args.hz}, execute_horizon: {args.execute_horizon}")
    print(f"  overlap: {args.overlap}, blend_decay: {args.blend_decay}")
    print(f"  max_steps: {args.max_steps}\n")

    while total_steps < args.max_steps:
        joints, grip = robot.get_state()
        adapter.set_current_state(joints, grip)
        img = camera.read()

        chunk = vla.predict(img, np.concatenate([joints, [grip]]), args.instruction)
        if chunk is None:
            total_steps += 1
            continue

        actions_to_execute = blender.blend(chunk)

        for i, act in enumerate(actions_to_execute):
            t0 = time.time()
            joints_now, grip_now = robot.get_state()
            adapter.set_current_state(joints_now, grip_now)
            cmd = adapter.convert(act, dt)
            robot.send(cmd["joint_targets"], cmd["gripper_open"], dt)

            total_steps += 1
            elapsed = time.time() - t0
            if dt - elapsed > 0:
                time.sleep(dt - elapsed)

            if total_steps % 20 == 0:
                print(f"  [step {total_steps}] chunk_action {i+1}/{len(actions_to_execute)} "
                      f"clamp={cmd['clamp_ratio']:.0%} dt={elapsed*1000:.0f}ms")
            if total_steps >= args.max_steps:
                break

    camera.release()
    print(f"\n=== Done: {total_steps} steps ===")


def run_simple(args):
    """기존 단순 루프 (Blending 없음, 비교용)"""
    from utils.doosan_recorder import CameraCapture
    vla = VLAClient(args.vla_url)
    robot = DoosanRobot()
    adapter = DoosanActionAdapter()
    camera = CameraCapture()
    dt = 1.0 / args.hz

    print(f"\n=== Deploy (Simple) @ {args.hz}Hz ===\n")
    for step in range(args.max_steps):
        t0 = time.time()
        joints, grip = robot.get_state()
        adapter.set_current_state(joints, grip)
        img = camera.read()
        act = vla.predict(img, np.concatenate([joints, [grip]]), args.instruction)
        if act is None: continue
        if act.ndim == 2: act = act[0]
        cmd = adapter.convert(act, dt)
        robot.send(cmd["joint_targets"], cmd["gripper_open"], dt)
        elapsed = time.time() - t0
        if dt - elapsed > 0: time.sleep(dt - elapsed)
        if step % 20 == 0:
            print(f"  [step {step}] clamp={cmd['clamp_ratio']:.0%} dt={elapsed*1000:.0f}ms")
    camera.release()


def main(args):
    if args.mode == "blend":
        run_with_blending(args)
    else:
        run_simple(args)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--vla-url", default="http://localhost:5555")
    p.add_argument("--instruction", default="Pick up the blue bottle and place it on the tray")
    p.add_argument("--hz", type=float, default=float(CONTROL_HZ))
    p.add_argument("--max-steps", type=int, default=200)
    p.add_argument("--mode", choices=["blend", "simple"], default="blend",
                    help="blend: temporal blending (권장), simple: 기존 단순 루프")
    p.add_argument("--execute-horizon", type=int, default=4,
                    help="한 chunk에서 실제 실행할 action 수 (작을수록 시각 피드백 자주)")
    p.add_argument("--overlap", type=int, default=4,
                    help="chunk 경계 blending 구간")
    p.add_argument("--blend-decay", type=float, default=0.7,
                    help="blending weight (0.7 권장)")
    main(p.parse_args())
